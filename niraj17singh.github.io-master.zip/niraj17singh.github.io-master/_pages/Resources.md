---
permalink: /Resources/
title: ""
excerpt: ""
author_profile: true
redirect_from: 
---

## Resources

1. [Computational Neuroscience Course](https://nptel.ac.in/courses/102106023/) which is available in nptel lecture from [Prof. V Srinivasa Chakravarthy](https://biotech.iitm.ac.in/index.php/v-srinivasa-chakravarthy/).
<br>

2. Some hand practice of convolutional neural network.<br> 

* [Convolutional Neural Network Theory](http://cs231n.github.io/)<br>

* [Convolutional Assignment](https://cv-tricks.com/tensorflow-tutorial/training-convolutional-neural-network-for-image-classification/)<br>

* [Tensorflow Standford Course](http://web.stanford.edu/class/cs20si/syllabus.html)


