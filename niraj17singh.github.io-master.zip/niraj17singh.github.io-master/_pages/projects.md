---
permalink: /Projects/
title: ""
excerpt: ""
author_profile: true
fullwidth: true
redirect_from: 
---
## Introduction
In Visual Attention Model, our Neuromotive team is divided into two groups. One is working in attention model and the other one is working in Eye-Tracker.  
## Attention Model for Object Detection<br>
* In this work we are focusing to implement the model which will search for the target object in the same manner as human looks at the interested object in the entire image. 


## Eye-Tracker <br>
* By analyzing eye-movement data, for example where people fixate and how long they fixate for, researchers can gain important insights into a number of cognitive operations involved in a wide range of behavior





