---
permalink: /Experience/
title: ""
excerpt: ""
author_profile: true
redirect_from: 
---
<p align="center">
  <b>Supervisor</b>
</p>
<br>

![test](Srinivasa.jpg){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%; bottom-margin:0px;"}
### [Prof. V Srinivasa Chakravarthy](https://biotech.iitm.ac.in/index.php/v-srinivasa-chakravarthy/)
<span style="font-size: 1em;">Email Id:</span>
[srinivasa.chakravarthy@gmail.com](mailto:srinivasa.chakravarthy@gmail.com) 

***

<p align="center">
  
  <b>Current Members</b>
  
</p>
<br>
![test](Niraj.jpg){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%; bottom-margin:0px;"}
### Niraj Kumar Singh
Project Associate
<br><span style="font-size: 1em;">Email Id:</span>
[neerajajaysingh17@gmail.com](mailto:neerajajaysingh17@gmail.com) 
<br>

***

<br>
![test](Sweta.jpeg){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%;"}    
### Sweta Kumari
Ph.D Student
<br><span style="font-size: 1em;">Email Id:</span>
[sweta.csebcetw@gmail.com](mailto:sweta.csebcetw@gmail.com) 
<br>

***

<br>
![test](Tamizharasan.gif){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%;"}    
### Tamizharasan Kanagamani
Ph.D Student
<br><span style="font-size: 1em;">Email Id:</span>
[tamizharasan.mit@gmail.com](mailto:tamizharasan.mit@gmail.com) 
<br>

***

<br>
![test](ojasvita.jpg){:.some-css-class style="width: 150px; height: 150px;  border-radius: 50%;"}
###  Ojasvita
Masters Dual Degree
<br><span style="font-size: 1em;">Email Id:</span>
[ojasvitawalgad@gmail.com](mailto:ojasvitawalgad@gmail.com) 
<br>

***

<br>
![test](nikhil.png){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%;"}
### Nikhil
Masters Dual Degree
<br><span style="font-size: 1em;">Email Id:</span>
[neerajajaysingh17@gmail.com](mailto:neerajajaysingh17@gmail.com) 
<br>

***

<br>
![test](rajat.png){:.some-css-class style="width: 150px; height: 150px; border-radius: 50%;"}
### Rajat<br>
Masters Dual Degree
<br><span style="font-size: 1em;">Email Id:</span>
[neerajajaysingh17@gmail.com](mailto:neerajajaysingh17@gmail.com) 
<br>

***

<br>

---
