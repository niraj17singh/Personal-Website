---
permalink: /
title: "About me"
excerpt: "About me"
author_profile: true
redirect_from: 
---
***

<p style='text-align: justify;'>  
I am currently a project associate leading the neuromotive team in computational neuroscience lab at Department of Biotechnology, IIT Madras, Chennai. </p>

<p style='text-align: justify;'>  
</p>


<Edit required>
